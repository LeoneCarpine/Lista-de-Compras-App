package com.example.listadecomprasapp

data class ListaCategoria(val titulo: String, val imgId: Int)