package com.example.listadecomprasapp

data class ItemCompra(val nome: String, var isChecked: Boolean = false)